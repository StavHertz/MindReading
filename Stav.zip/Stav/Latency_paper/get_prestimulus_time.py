from get_time_window_buffer import get_time_window_buffer

def get_prestimulus_time():
	return 100 + get_time_window_buffer()