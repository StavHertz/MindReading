def get_hist_from_spike_train(spike_train):
	