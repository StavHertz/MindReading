def get_time_window_buffer():
	return 150