def get_all_cortical_regions():
	return ['VISal', 'VISam', 'VISl', 'VISp', 'VISpm', 'VISrl']