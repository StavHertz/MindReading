def get_all_stimuli():
	return ['natural_images']