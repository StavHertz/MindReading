def get_baseline_window_size():
	return 20