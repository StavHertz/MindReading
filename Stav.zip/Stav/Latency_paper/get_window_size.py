from get_time_window_buffer import get_time_window_buffer

def get_window_size():
	return 350 + 2*get_time_window_buffer()