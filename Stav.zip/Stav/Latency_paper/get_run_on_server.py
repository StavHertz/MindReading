def get_run_on_server():
	return False