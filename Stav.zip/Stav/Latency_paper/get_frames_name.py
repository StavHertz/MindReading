
def get_frames_name(stim_type):
	if stim_type == 'natural_scenes':
		return 'frame'
	if stim_type == 'flash_250ms':
		return 'color'