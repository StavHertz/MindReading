def get_all_regions():
	return ['TH', 'SCs', 'DG', 'CA', 'VISl', 'VISp', 'VISrl', 'VISal', 'VISam', 'VISpm']